document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
    });
  }

  document.querySelectorAll('[data-demo-form]').forEach(form => {
    form.addEventListener('submit', event => {
      event.preventDefault();
      const notice = form.querySelector('.notice');
      if (notice) {
        notice.textContent = form.dataset.success || 'Thank you! This demo form was submitted locally.';
        notice.classList.add('show');
      }
      form.reset();
    });
  });

  const filterButtons = document.querySelectorAll('[data-filter]');
  const courseCards = document.querySelectorAll('[data-category]');
  const search = document.querySelector('#course-search');
  let activeFilter = 'all';
  function filterCourses() {
    const term = search ? search.value.trim().toLowerCase() : '';
    let shown = 0;
    courseCards.forEach(card => {
      const matchesCategory = activeFilter === 'all' || card.dataset.category === activeFilter;
      const matchesSearch = card.textContent.toLowerCase().includes(term);
      const visible = matchesCategory && matchesSearch;
      card.hidden = !visible;
      if (visible) shown++;
    });
    const empty = document.querySelector('.empty-state');
    if (empty) empty.classList.toggle('show', shown === 0);
  }
  filterButtons.forEach(button => button.addEventListener('click', () => {
    activeFilter = button.dataset.filter;
    filterButtons.forEach(item => item.classList.toggle('active', item === button));
    filterCourses();
  }));
  if (search) search.addEventListener('input', filterCourses);

  document.querySelectorAll('[data-enroll]').forEach(button => button.addEventListener('click', () => {
    const original = button.textContent;
    button.textContent = 'Added to learning list ✓';
    button.disabled = true;
    button.setAttribute('aria-label', 'Course added to learning list');
    window.setTimeout(() => { button.textContent = original; button.disabled = false; }, 2200);
  }));
});
