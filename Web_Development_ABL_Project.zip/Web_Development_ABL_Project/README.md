# Web Development Activity-Based Learning Project

This project completes **three case studies** from the supplied Web Development Activity-Based Learning instructions:

1. Personal Portfolio Website
2. College Information and Admissions Website
3. Online Learning Platform Interface

## Technologies
- HTML5 for semantic page structure
- CSS3 for responsive layouts, cards, transitions, and animations
- JavaScript for navigation, course filtering, and interactive UI elements

## How to run
1. Extract the ZIP file.
2. Open `index.html` in a web browser, or open the folder in Visual Studio Code.
3. For the best development experience, use the VS Code **Live Server** extension.
4. From the home page, open any of the three case studies.

## Project structure
```text
Web_Development_ABL_Project/
├── index.html
├── README.md
├── assets/
│   └── styles.css
├── js/
│   └── main.js
├── case-study-1-portfolio/
│   └── index.html
├── case-study-2-college/
│   └── index.html
└── case-study-3-learning-platform/
    └── index.html
```

## Notes
- Sample student, college, course, contact, and achievement details are demonstration content. Replace them with your actual details before submission.
- The forms and buttons are front-end demonstrations; no backend, database, real authentication, or actual course enrollment is connected.
